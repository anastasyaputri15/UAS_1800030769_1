<?php 

require_once 'koneksi.php';

$key = $_POST['key'];

$name     = $_POST['name'];
$harga    = $_POST['harga'];
$jumlah   = $_POST['jumlah'];
$status   = $_POST['status'];
$tanggal  = $_POST['tanggal'];
$picture  = $_POST['picture'];

if ( $key == "insert" ){

    $tanggal_newformat = date('Y-m-d', strtotime($tanggal));

    $query = "INSERT INTO barang (name,harga,jumlah,status,tanggal)
    VALUES ('$name', '$harga', '$jumlah', '$status', '$tanggal_newformat') ";

        if ( mysqli_query($conn, $query) ){

            if ($picture == null) {

                $finalPath = "/webs/logo.png"; 
                $result["value"] = "1";
                $result["message"] = "Success";
    
                echo json_encode($result);
                mysqli_close($conn);

            } else {

                $id = mysqli_insert_id($conn);
                $path = "images/$id.jpeg";
                $finalPath = "/webs/".$path;

                $insert_picture = "UPDATE barang SET picture='$finalPath' WHERE id='$id' ";
            
                if (mysqli_query($conn, $insert_picture)) {
            
                    if ( file_put_contents( $path, base64_decode($picture) ) ) {
                        
                        $result["value"] = "1";
                        $result["message"] = "Success!";
            
                        echo json_encode($result);
                        mysqli_close($conn);
            
                    } else {
                        
                        $response["value"] = "0";
                        $response["message"] = "Error! ".mysqli_error($conn);
                        echo json_encode($response);

                        mysqli_close($conn);
                    }

                }
            }

        } 
        else {
            $response["value"] = "0";
            $response["message"] = "Error! ".mysqli_error($conn);
            echo json_encode($response);

            mysqli_close($conn);
        }
}

?>

